

/**
 *
 * @author Giovanni
 */
public class Exemplo4 {

    public static void main(String[] args) {
        
        int cont;
     int cont = 1;
     System.out.println("          TABUADA DO 7\n");
     while (cont < = 10 ) {
         System.out.println("7 +" + cont+ " = " + cont * 7);
         cont++
    }
    
}
}
